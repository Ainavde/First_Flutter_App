import 'package:flutter/material.dart';

void main() {
  runApp(MeasuresConverterApp());
}

class MeasuresConverterApp extends StatelessWidget {
  const MeasuresConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Measures Converter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MeasuresConverterScreen(),
    );
  }
}

class MeasuresConverterScreen extends StatefulWidget {
  const MeasuresConverterScreen({super.key});

  @override
  _MeasuresConverterScreenState createState() => _MeasuresConverterScreenState();
}

class _MeasuresConverterScreenState extends State<MeasuresConverterScreen> {
  final TextEditingController _valueController = TextEditingController();
  String _fromUnit = 'meters';
  String _toUnit = 'feet';
  double? _convertedValue;

  final Map<String, double> _conversionRates = {
    'meters': 1.0,
    'feet': 3.28084,
    'kilometers': 0.001,
    'miles': 0.000621371,
    'grams': 1.0,
    'pounds': 0.00220462,
    'kilograms': 0.001,
  };

  void _convert() {
    double? value = double.tryParse(_valueController.text);
    if (value != null) {
      double fromRate = _conversionRates[_fromUnit]!;
      double toRate = _conversionRates[_toUnit]!;
      double convertedValue = (value / fromRate) * toRate;
      setState(() {
        _convertedValue = convertedValue;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Measures Converter'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _valueController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Value',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16.0),
            const Text('From', style: TextStyle(fontSize: 16.0)),
            DropdownButton<String>(
              value: _fromUnit,
              items: _conversionRates.keys.map((String unit) {
                return DropdownMenuItem<String>(
                  value: unit,
                  child: Text(unit),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _fromUnit = value!;
                });
              },
            ),
            const SizedBox(height: 16.0),
            const Text('To', style: TextStyle(fontSize: 16.0)),
            DropdownButton<String>(
              value: _toUnit,
              items: _conversionRates.keys.map((String unit) {
                return DropdownMenuItem<String>(
                  value: unit,
                  child: Text(unit),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _toUnit = value!;
                });
              },
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _convert,
              child: const Text('Convert'),
            ),
            const SizedBox(height: 16.0),
            if (_convertedValue != null)
              Text(
                '${_valueController.text} $_fromUnit are ${_convertedValue!.toStringAsFixed(3)} $_toUnit',
                style: const TextStyle(fontSize: 18.0),
              ),
          ],
        ),
      ),
    );
  }
}
